#!/usr/bin/env python
# -*- coding: utf-8 -*-  
import re
from os import listdir
from os.path import isfile, join

path = "./bugs/"
target = "./menu.txt"

def get_info(file):
	fp = open(path+file,'r')
	file_content = fp.read()
	re_time = re.search(r'�ύʱ�䣺\s(.{11})', file_content)
	re_title = re.search(r'<title>\s(.+?) \|', file_content)
	re_author = re.search(r'©�����ߣ�\s(.+)</h3>', file_content)
	print file
	time = re_time.group(1)
	title = re_title.group(1)
	author = re_author.group(1)
	fp.close()
	
	return {'file':file, 'time':time, 'title':title, 'author':author}
	
def write_info(data, fp):
	content = '<tr>'
	content += '<th>'+data['time']+'</th>'
	content += '<td><a href="bugs/'+data['file']+'">'+data['title']+'</a></td>'
	content += '<th>'+data['author']+'<th></tr>\n'
	
	fp.writelines(content)
	
if __name__ == '__main__':
	fp = open(target,'a')
	
	bug_files = [file for file in listdir(path) if isfile(join(path,file))]
	for file in bug_files:
		data = get_info(file)
		write_info(data, fp)
		
	fp.close()
		